package com.example.fpsboost

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {
    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        try { Shizuku.requestPermission(100) } catch (_: Throwable) {}
    }

    fun ready(): Boolean = isRunning() && hasPermission()

    // Runs a shell command with Shizuku privileges. Call from a background thread.
    fun run(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            out + err
        } catch (e: Throwable) {
            "ERR: ${e.message}"
        }
    }

    fun killBackground(): String = run("am kill-all")

    fun gameMode(pkg: String, performance: Boolean): String =
        run("cmd game mode ${if (performance) "performance" else "standard"} $pkg")

    fun resetScreen(): String = run("wm size reset; wm density reset")

    // percent: 100 = normal. Returns true if applied.
    fun setScale(percent: Int): Boolean {
        if (percent >= 100) { resetScreen(); return true }
        val size = Regex("Physical size: (\\d+)x(\\d+)").find(run("wm size")) ?: return false
        val den = Regex("Physical density: (\\d+)").find(run("wm density")) ?: return false
        val w = size.groupValues[1].toInt() * percent / 100 / 2 * 2
        val h = size.groupValues[2].toInt() * percent / 100 / 2 * 2
        val d = den.groupValues[1].toInt() * percent / 100
        run("wm size ${w}x$h; wm density $d")
        return true
    }
}
