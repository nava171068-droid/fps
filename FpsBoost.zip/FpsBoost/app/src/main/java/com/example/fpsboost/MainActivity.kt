package com.example.fpsboost

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var gameText: TextView
    private lateinit var shText: TextView
    private lateinit var resBtn: Button
    private val scales = intArrayOf(100, 80, 70, 60)
    private val prefs by lazy { getSharedPreferences("fps", MODE_PRIVATE) }
    private val nm by lazy { getSystemService(NOTIFICATION_SERVICE) as NotificationManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        S.load(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        info = TextView(this).apply { textSize = 18f }
        gameText = TextView(this).apply { textSize = 16f; setPadding(0, 32, 0, 8) }
        layout.addView(info)
        layout.addView(btn(S.t("refresh")) { refresh() })
        layout.addView(gameText)
        layout.addView(btn(S.t("pick")) { pickGame() })
        layout.addView(btn(S.t("perm_overlay")) { openOverlaySettings() })
        layout.addView(TextView(this).apply { text = S.t("hint2"); textSize = 13f })
        layout.addView(btn(S.t("perm_dnd")) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        layout.addView(btn(S.t("play")) { play() })
        layout.addView(btn(S.t("stop")) { stopAll() })
        layout.addView(TextView(this).apply { text = S.t("sh_title"); textSize = 16f; setPadding(0, 40, 0, 8) })
        shText = TextView(this).apply { textSize = 14f }
        layout.addView(shText)
        layout.addView(btn(S.t("sh_connect")) { connectShizuku() })
        resBtn = btn("") { cycleScale() }
        layout.addView(resBtn)
        layout.addView(btn(S.t("sh_ram")) { freeRamNow() })
        layout.addView(btn(S.t("sh_reset")) { resetScreenNow() })
        layout.addView(TextView(this).apply { text = S.t("sh_warn"); textSize = 13f })
        layout.addView(btn(S.t("display")) {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        })
        layout.addView(btn(S.t("battsaver")) {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        })
        layout.addView(btn(S.t("language")) { pickLanguage() })
        setContentView(ScrollView(this).apply { addView(layout) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val freeMb = mi.availMem / 1024 / 1024
        val totalMb = mi.totalMem / 1024 / 1024
        val warn = if (temp >= 42) "\n${S.t("hot_warn")}" else ""
        info.text = "${S.t("battery")}: $level%\n${S.t("temp")}: $temp °C\n${S.t("ram")}: $freeMb / $totalMb MB$warn"
        val label = prefs.getString("label", null)
        gameText.text = "${S.t("game_is")}: ${label ?: S.t("none")}"
        shText.text = when {
            !ShizukuHelper.isRunning() -> S.t("sh_off")
            !ShizukuHelper.hasPermission() -> S.t("sh_perm")
            else -> S.t("sh_ready")
        }
        resBtn.text = "${S.t("sh_res")}: ${prefs.getInt("scale", 100)}%"
    }

    private fun connectShizuku() {
        if (!ShizukuHelper.isRunning()) {
            toast(S.t("sh_off_hint"))
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
        } else if (!ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission()
        } else {
            toast(S.t("sh_ready"))
        }
    }

    private fun cycleScale() {
        val cur = prefs.getInt("scale", 100)
        val next = scales[(scales.indexOf(cur) + 1) % scales.size]
        prefs.edit().putInt("scale", next).apply()
        refresh()
    }

    private fun freeRamNow() {
        if (!ShizukuHelper.ready()) { toast(S.t("sh_need")); return }
        Thread {
            ShizukuHelper.killBackground()
            runOnUiThread { toast(S.t("sh_done")); refresh() }
        }.start()
    }

    private fun resetScreenNow() {
        if (!ShizukuHelper.ready()) { toast(S.t("sh_need")); return }
        Thread {
            ShizukuHelper.resetScreen()
            runOnUiThread { toast(S.t("sh_done")) }
        }.start()
    }

    private fun pickLanguage() {
        AlertDialog.Builder(this)
            .setTitle(S.t("lang_title"))
            .setItems(arrayOf("English", "ไทย")) { _, i ->
                S.set(this, if (i == 1) "th" else "en")
                recreate()
            }
            .show()
    }

    private fun pickGame() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this)
            .setTitle(S.t("pick_title"))
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                prefs.edit().putString("pkg", apps[i].first).putString("label", apps[i].second).apply()
                refresh()
            }
            .show()
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun play() {
        val pkg = prefs.getString("pkg", null)
        if (pkg == null) { toast(S.t("need_game")); return }
        if (!Settings.canDrawOverlays(this)) {
            toast(S.t("need_overlay"))
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val svc = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)

        if (nm.isNotificationPolicyAccessGranted) {
            prefs.edit().putInt("prevFilter", nm.currentInterruptionFilter).apply()
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        val launchGame = {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) startActivity(launch) else toast(S.t("cant_open"))
        }
        if (ShizukuHelper.ready()) {
            val scale = prefs.getInt("scale", 100)
            Thread {
                ShizukuHelper.killBackground()
                ShizukuHelper.gameMode(pkg, true)
                ShizukuHelper.setScale(scale)
                runOnUiThread { launchGame() }
            }.start()
        } else {
            launchGame()
        }
    }

    private fun stopAll() {
        stopService(Intent(this, OverlayService::class.java))
        if (nm.isNotificationPolicyAccessGranted && prefs.contains("prevFilter")) {
            nm.setInterruptionFilter(prefs.getInt("prevFilter", NotificationManager.INTERRUPTION_FILTER_ALL))
            prefs.edit().remove("prevFilter").apply()
        }
        if (ShizukuHelper.ready()) {
            val pkg = prefs.getString("pkg", null)
            Thread {
                ShizukuHelper.resetScreen()
                if (pkg != null) ShizukuHelper.gameMode(pkg, false)
            }.start()
        }
        toast(S.t("stopped"))
    }
}
