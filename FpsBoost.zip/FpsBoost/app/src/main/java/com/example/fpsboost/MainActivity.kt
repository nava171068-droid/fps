package com.example.fpsboost

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        info = TextView(this).apply { textSize = 18f }
        layout.addView(info)

        layout.addView(Button(this).apply {
            text = "รีเฟรชข้อมูลเครื่อง"
            setOnClickListener { refresh() }
        })
        layout.addView(Button(this).apply {
            text = "ตั้งค่าหน้าจอ (รีเฟรชเรต)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "ตั้งค่าโหมดประหยัดแบต (ควรปิดตอนเล่นเกม)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
        })
        setContentView(layout)
        refresh()
    }

    private fun refresh() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val freeMb = mi.availMem / 1024 / 1024
        val totalMb = mi.totalMem / 1024 / 1024
        val warn = if (temp >= 42) "\n⚠️ เครื่องร้อน เกมอาจกระตุก" else ""
        info.text = "แบตเตอรี่: $level%\nอุณหภูมิ: $temp °C\nแรมว่าง: $freeMb / $totalMb MB$warn"
    }
}
