package com.example.fpsboost

import android.content.Context

object S {
    var lang = "en"

    fun load(c: Context) {
        lang = c.getSharedPreferences("fps", Context.MODE_PRIVATE).getString("lang", "en") ?: "en"
    }

    fun set(c: Context, l: String) {
        c.getSharedPreferences("fps", Context.MODE_PRIVATE).edit().putString("lang", l).apply()
        lang = l
    }

    private val en = mapOf(
        "refresh" to "Refresh device info",
        "battery" to "Battery",
        "temp" to "Temperature",
        "ram" to "Free RAM",
        "hot_warn" to "⚠️ Device is hot, games may lag",
        "game_is" to "Selected game",
        "none" to "not selected",
        "pick" to "1) Choose game",
        "perm_overlay" to "2) Allow overlay on screen",
        "hint2" to "Tip: find FPS Helper in the list, turn on \"Display over other apps\", then press Back.",
        "perm_dnd" to "3) Allow Do Not Disturb (optional)",
        "play" to "▶ Start playing",
        "stop" to "■ Stop overlay & restore settings",
        "display" to "Display settings (refresh rate)",
        "battsaver" to "Battery saver settings (turn off when gaming)",
        "language" to "Language: English",
        "lang_title" to "Choose language",
        "pick_title" to "Choose game",
        "need_game" to "Please choose a game first (button 1)",
        "need_overlay" to "Please allow overlay first (button 2)",
        "cant_open" to "Cannot open the game",
        "stopped" to "Stopped",
        "notif_title" to "FPS Helper is running",
        "notif_text" to "Tap to open the app",
        "ov_ram" to "Free RAM",
        "ov_bat" to "Bat",
        "ov_hot" to "Hot! Let it cool down",
        "sh_title" to "— Shizuku (advanced, optional) —",
        "sh_off" to "Shizuku: not running",
        "sh_perm" to "Shizuku: running, tap Connect to allow",
        "sh_ready" to "Shizuku: ready ✅",
        "sh_connect" to "Connect Shizuku",
        "sh_off_hint" to "Install Shizuku (shizuku.rikka.app), start it with Wireless debugging, then come back.",
        "sh_res" to "Resolution while gaming",
        "sh_ram" to "Free RAM now (close background apps)",
        "sh_reset" to "Reset screen size",
        "sh_done" to "Done",
        "sh_warn" to "If the screen looks wrong, tap \"Reset screen size\".",
        "sh_need" to "Connect Shizuku first"
    )

    private val th = mapOf(
        "refresh" to "รีเฟรชข้อมูลเครื่อง",
        "battery" to "แบตเตอรี่",
        "temp" to "อุณหภูมิ",
        "ram" to "แรมว่าง",
        "hot_warn" to "⚠️ เครื่องร้อน เกมอาจกระตุก",
        "game_is" to "เกมที่เลือก",
        "none" to "ยังไม่ได้เลือก",
        "pick" to "1) เลือกเกม",
        "perm_overlay" to "2) ให้สิทธิ์แสดงข้อมูลลอยบนจอ",
        "hint2" to "วิธีทำ: หาชื่อ FPS Helper ในรายการ เปิดสวิตช์ \"แสดงทับแอปอื่น\" แล้วกดย้อนกลับ",
        "perm_dnd" to "3) ให้สิทธิ์ห้ามรบกวน (ไม่บังคับ)",
        "play" to "▶ เริ่มเล่นเกม",
        "stop" to "■ หยุดข้อมูลลอย และคืนค่าต่างๆ",
        "display" to "ตั้งค่าหน้าจอ (รีเฟรชเรต)",
        "battsaver" to "ตั้งค่าโหมดประหยัดแบต (ควรปิดตอนเล่นเกม)",
        "language" to "ภาษา: ไทย",
        "lang_title" to "เลือกภาษา",
        "pick_title" to "เลือกเกม",
        "need_game" to "กรุณาเลือกเกมก่อน (ปุ่ม 1)",
        "need_overlay" to "ต้องให้สิทธิ์แสดงข้อมูลลอยก่อน (ปุ่ม 2)",
        "cant_open" to "เปิดเกมไม่ได้",
        "stopped" to "หยุดแล้ว",
        "notif_title" to "FPS Helper กำลังทำงาน",
        "notif_text" to "แตะเพื่อเปิดแอพ",
        "ov_ram" to "แรมว่าง",
        "ov_bat" to "แบต",
        "ov_hot" to "ร้อน! พักเครื่อง",
        "sh_title" to "— Shizuku (ขั้นสูง ไม่บังคับ) —",
        "sh_off" to "Shizuku: ยังไม่ทำงาน",
        "sh_perm" to "Shizuku: ทำงานอยู่ กดเชื่อมต่อเพื่ออนุญาต",
        "sh_ready" to "Shizuku: พร้อมใช้งาน ✅",
        "sh_connect" to "เชื่อมต่อ Shizuku",
        "sh_off_hint" to "ติดตั้ง Shizuku (shizuku.rikka.app) แล้วเปิดใช้ผ่านไวไฟ (Wireless debugging) จากนั้นกลับมาที่แอพนี้",
        "sh_res" to "ความละเอียดตอนเล่นเกม",
        "sh_ram" to "เคลียร์แรมตอนนี้ (ปิดแอพเบื้องหลัง)",
        "sh_reset" to "คืนค่าขนาดหน้าจอ",
        "sh_done" to "เรียบร้อย",
        "sh_warn" to "ถ้าหน้าจอผิดปกติ กด \"คืนค่าขนาดหน้าจอ\"",
        "sh_need" to "ต้องเชื่อมต่อ Shizuku ก่อน"
    )

    fun t(key: String): String = (if (lang == "th") th else en)[key] ?: key
}
